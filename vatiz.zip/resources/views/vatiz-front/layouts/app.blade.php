@include('vatiz-front.layouts.header')
	@yield('header')
	@yield('content')
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v4.0&appId=2422498754661034&autoLogAppEvents=1"></script>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v4.0&appId=2422498754661034&autoLogAppEvents=1"></script>
@include('vatiz-front.layouts.footer')