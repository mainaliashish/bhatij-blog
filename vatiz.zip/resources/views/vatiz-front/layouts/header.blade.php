<!DOCTYPE HTML>
<head>
<title>@yield('title')</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="{{ asset('/front/css/bootstrap.css') }}" rel='stylesheet' type='text/css' />

<link rel="icon" href="{{ asset('logo/site-logo.png') }}">
<!-- Custom Theme files -->
<link href='//fonts.googleapis.com/css?family=Raleway:400,600,700' rel='stylesheet' type='text/css'>
<link href="{{ asset('front/css/style.css') }}" rel='stylesheet' type='text/css' />
<script src="{{ asset('front/js/jquery-1.11.1.min.js') }}"></script>
<script src="{{ asset('front/js/bootstrap.min.js') }}"></script>
<!-- animation-effect -->
<link href="{{ asset('front/css/animate.min.css') }}" rel="stylesheet">
<script src="{{ asset('front/js/wow.min.js') }}"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head>