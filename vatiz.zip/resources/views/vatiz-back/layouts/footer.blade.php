<script src="{{ asset('back/js/bootstrap.js') }}"></script>
<script src="{{ asset('back/js/jquery.dcjqaccordion.2.7.js') }}"></script>
<script src="{{ asset('back/js/scripts.js') }}"></script>
<script src="{{ asset('back/js/jquery.slimscroll.js') }}"></script>
<script src="{{ asset('back/js/jquery.nicescroll.js') }}"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="{{ asset('back/js/flot-chart/excanvas.min.js') }}"></script><![endif]-->
<script src="{{ asset('back/js/jquery.scrollTo.js') }}"></script>
<!-- morris JavaScript -->


