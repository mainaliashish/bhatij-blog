<?php $__env->startSection('title'); ?>
...::Bhatij Category::..
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('front/css/component.css')); ?>" />
<script src="<?php echo e(asset('front/js/modernizr.custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('vatiz-front.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="technology">
	<div class="container">
		<div class="col-md-9 technology-left">
			<div class="music">
				<div class="effect-grid">
						<h3 class="w3"><?php echo e($category->name); ?></h3>
						<ul class="grid cs-style-3">
						<?php if($category->posts->count() > 0): ?>
						<?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<figure>
							<a href="<?php echo e(route('single', $post->slug)); ?>">	<img src="<?php echo e(asset($post->image)); ?>" alt=""> </a>
								<figcaption>
							       <h4>
										<?php echo e(str_limit($post->title, 14, '......')); ?> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href='<?php echo e(route('single', $post->slug)); ?>' class='btn btn-success btn-sm'>  &nbsp;Read More</a>
									</h4>
								</figcaption>
							</figure>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<h3 style="color: red;">Oopss.. NO Post in this Category..</h3>
						<a href="<?php echo e(route('main-page')); ?>" class="btn btn-danger" style="margin-top: 15px;">Return Back</a>
						<?php endif; ?>
						<div class="clearfix"></div>
					</ul>
				</div>
			</div>
		</div>

		<?php echo $__env->make('vatiz-front.layouts.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/category.blade.php ENDPATH**/ ?>