<!DOCTYPE html>

<?php echo $__env->make('vatiz-back.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('header'); ?>
<body>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('vatiz-back.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('footer'); ?>
<?php echo $__env->make('partials.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/layouts/layout.blade.php ENDPATH**/ ?>