		<!-- technology-right -->
		<div class="col-md-3 technology-right">
				<div class="blo-top1">

					<div class="tech-btm">
					<div class="search-1">
							<form action="<?php echo e(route('results')); ?>" method="GET">
								<input type="search" name="query" value="search post" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}" required="">
								<input type="submit" value=" ">
							</form>
						</div>
					<h4>Latest Posts</h4>
						<?php if($posts): ?>
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="blog-grids">
							<div class="blog-grid-left">
								<a href="<?php echo e(route('single', ['slug' => $post->slug])); ?>"><img src="<?php echo e(asset($post->image)); ?>" class="img-responsive" alt=""></a>
							</div>
							<div class="blog-grid-right">
								<h5><a href="<?php echo e(route('single', ['slug' => $post->slug])); ?>"><?php echo e($post->title); ?></a> </h5>
							</div>
							<div class="clearfix"> </div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

					<div class="insta wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<h4>More Categories</h4>
						<ul>
						<?php if($categories): ?>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a href="<?php echo e(route('category', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
						<div class="clearfix"></div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						</ul>
					</div>
</div>
</div>
</div><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/layouts/right-nav.blade.php ENDPATH**/ ?>