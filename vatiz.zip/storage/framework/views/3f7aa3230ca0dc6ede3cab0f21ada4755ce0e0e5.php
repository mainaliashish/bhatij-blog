<?php $__env->startSection('title'); ?>
...::Bhatij Single Page::..
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('vatiz-front.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- technology-left -->
	<div class="technology">
	<div class="container">
		<div class="col-md-9 technology-left">
			<div class="agileinfo">

			<div class="single">
			   <img src="<?php echo e(asset($post->image)); ?>" class="img-responsive" alt="">
			    <div class="b-bottom">
			      <h5 class="top"><?php echo e($post->title); ?></h5>
				   <p class="sub"><?php echo e($post->description); ?></p>
			       <h6> BY <a href="<?php echo e(route('about')); ?>" style="    color: #fa4b2a;font-weight: 600;font-size: 16px;"><?php echo e($post->author); ?> </a><p style="margin-top: 20px;font-weight: 600;">Published at: <strong style="color: #fa4b2a;"><?php echo e($post -> created_at->toFormattedDateString()); ?></strong></p>
			       <?php echo $__env->make('partials.share', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<div class="response">
					<h4>Responses</h4>
					<div class="media response-info">
						<?php echo $__env->make('partials.disqus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	<?php echo $__env->make('vatiz-front.layouts.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- technology-right -->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/single.blade.php ENDPATH**/ ?>