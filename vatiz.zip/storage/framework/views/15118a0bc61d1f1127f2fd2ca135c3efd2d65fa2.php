<?php $__env->startSection('content'); ?>
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header end-->
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class=" wrapper">
		<div class="agile-grid">
		<h2 class="w3ls_head"><?php echo e($post->title); ?></h2>
            <div class="row">
                <div class="col-lg-12">
                    <section class="panel">
                        <img src="<?php echo e(asset($post->image)); ?>" alt="<?php echo e($post->title); ?>" height="500px" width="100%" style="padding: 20px">
                        <div class="panel-body">
                            <?php echo $post->description; ?>

                            <div class="clearfix"></div>
                     <a href="#" class="btn btn-primary" style="margin-top: 20px;"><?php echo e($post->category->name); ?></a>
                        <div class="buttons pull-right" style="padding: 10px;">
                <a href="<?php echo e(route('posts.edit', $post -> id)); ?>" class="btn btn-info">Edit</a></td>
                <a href="<?php echo e(route('posts.trash', $post -> id)); ?>" class="btn  btn-warning">Trash</a>
                <a href="<?php echo e(route('posts.delete', $post -> id)); ?>" class="btn btn-danger">Delete</a>
                        </div>
                        </div>
                    </section>
                </div>
            </div>
		</div>
        </section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/posts/show.blade.php ENDPATH**/ ?>