<?php $__env->startSection('content'); ?>
<section id="container">
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
</section>
<section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/home.blade.php ENDPATH**/ ?>