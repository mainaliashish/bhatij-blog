<head>
<title>Bhatij Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="#" />

<link rel="icon" href="<?php echo e(asset('logo/final.png')); ?>" type="image/icon type">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- bootstrap-css -->
<link rel="stylesheet" href="<?php echo e(asset('back/css/bootstrap.min.css')); ?>" >
<!-- Custom CSS -->
<link href="<?php echo e(asset('back/css/style.css')); ?>" rel='stylesheet' type='text/css' />
<link href="<?php echo e(asset('back/css/style-responsive.css')); ?>" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="<?php echo e(asset('back/css/font.css')); ?>" type="text/css"/>
<link href="<?php echo e(asset('back/css/font-awesome.css')); ?>" rel="stylesheet">

<script src="<?php echo e(asset('back/js/jquery2.0.3.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('back/css/toastr.css')); ?>" />

</head>
<body><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/layouts/header.blade.php ENDPATH**/ ?>