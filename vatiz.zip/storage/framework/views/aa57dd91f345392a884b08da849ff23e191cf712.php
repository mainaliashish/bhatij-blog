<?php $__env->startSection('header'); ?>
<style>
	.table {
    width: 100%;
    max-width: 100%;
    margin-bottom: 20px;
    background: aliceblue;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
	color: royalblue;
}

a:focus, a:hover {
    color: chocolate;
    font-weight: 600;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="container">
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header end-->
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     List of All Posts
    </div>
    <div>
      <table class="table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Category</th>
            <th data-breakpoints="xs">Title</th>
            <th>Editing</th>
            <th>Trashing</th>
          </tr>
        </thead>
        <?php if($posts): ?>
        <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><img src="<?php echo e($post->image); ?>" alt="<?php echo e($post->title); ?>" height="90px" width="120px"></td>
            <td><?php echo e($post->category->name); ?></td>
            <td> <a href="<?php echo e(route('posts.show', $post->id)); ?>"> <?php echo e($post->title); ?> </a></td>
      			<td><a href="<?php echo e(route('posts.edit', $post -> id)); ?>" class="btn btn-sm btn-info">Edit</a></td>
      			<td><a href="<?php echo e(route('posts.trash', $post -> id)); ?>" class="btn btn-sm btn-warning">Trash</a></td>
					</tr>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php endif; ?>
      </table>
    </div>
    <div style="padding: 12px;background: aliceblue;">
      <?php echo e($posts->links()); ?>

    </div>
  </div>
</div>

		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/posts/index.blade.php ENDPATH**/ ?>