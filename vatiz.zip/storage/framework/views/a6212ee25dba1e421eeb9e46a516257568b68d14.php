<script src="<?php echo e(asset('back/js/toastr.js')); ?>" ></script>
<script type="text/javascript">
   <?php if(Session::has('success')): ?>
   toastr.success("<?php echo e(Session::get('success')); ?>")
   <?php else: ?> if(Session::has('error'))
    toastr.error("<?php echo e(Session::get('success')); ?>")
   <?php endif; ?>
</script><?php /**PATH /home/ashish/Sites/vatiz/resources/views/partials/toastr.blade.php ENDPATH**/ ?>