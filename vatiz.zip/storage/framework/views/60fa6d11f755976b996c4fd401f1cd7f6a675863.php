<script src="<?php echo e(asset('back/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('back/js/jquery.dcjqaccordion.2.7.js')); ?>"></script>
<script src="<?php echo e(asset('back/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('back/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('back/js/jquery.nicescroll.js')); ?>"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="<?php echo e(asset('back/js/flot-chart/excanvas.min.js')); ?>"></script><![endif]-->
<script src="<?php echo e(asset('back/js/jquery.scrollTo.js')); ?>"></script>
<!-- morris JavaScript -->


<?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/layouts/footer.blade.php ENDPATH**/ ?>