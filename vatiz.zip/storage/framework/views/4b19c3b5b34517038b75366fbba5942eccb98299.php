<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('back/css/trix.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('back/css/flatpicker.css')); ?>" />
<style type="text/css">
	trix-editor {
		height: 500px !important;
		max-height: 200px;
	  	overflow-y: auto !important;
	}

header.panel-heading.custom {
    background: antiquewhite;
    color: sienna;
    font-size: x-large;
    font-family: sans-serif;
    font-weight: 600;
    box-shadow: 3px 3px darkolivegreen;
}

.alert.alert-danger {
    color: firebrick;
    font-size: 16px;
    font-family: sans-serif;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="container">
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header end-->
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	 <div class="panel panel-default">
    <div class="panel-heading">
    <?php if(isset($post)): ?>
     Edit Post
    <?php else: ?>
     Create a Blog Post
    <?php endif; ?>
    </div>

 	<?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	<div class="custom" style="padding: 12px">
 		<?php if(isset($post)): ?>
		<?php echo Form::model($post, ['method'=>'PATCH', 'route' => ['posts.update', $post->id], 'files'=>true]); ?>

		<?php else: ?>
		<?php echo e(Form::open(array('method'=>'POST','route' => 'posts.store', 'files'=>true))); ?>

		<?php endif; ?>
		<div class="form-group">
			<?php echo Form::label('title', 'Title : ', ['class' => 'font-weight-bold']); ?>

			<?php echo Form::text('title', isset($post) ? $post->title : ' ' , ['class' => 'form-control','placeholder'=>'Enter title']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('description', 'Description : ', ['class' => ' font-weight-bold']); ?>

			<input id="x" type="hidden" name="description" value="<?php echo e(isset($post) ? $post->description : ' '); ?>">
  			<trix-editor input="x"></trix-editor>
		</div>

		<?php if(isset($post)): ?>
		<div class="form-group">
			<img src="<?php echo e(asset($post->image)); ?>" alt="" style="width: 100%;" height="500px">
		</div>
		<?php endif; ?>
		<div class="form-group">
			<?php echo Form::label('image', 'Image :', ['class' => 'font-weight-bold']); ?>

			<?php echo Form::file('image',null, ['class' => 'form-control']); ?>

		</div>

        <div class="form-group">
          <?php echo Form::label('category_id', 'Category:', ['class' => 'font-weight-bold']); ?>

          <?php if(isset($categories) && count($categories) > 0): ?>
          <?php echo Form::select('category_id', [''=>'Choose Options'] + $categories , null, ['class'=>'form-control']); ?>

          <?php endif; ?>
        </div>

		<div class="form-group right">
			<?php echo e(Form::submit(isset($post) ? 'Update Post' : 'Create Post',['class' => 'btn btn-success'])); ?>

		</div>
		<?php echo Form::close(); ?>

 	</div>
<?php echo $__env->make('vatiz-back.layouts.back-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('back/js/trix.js')); ?>"></script>
<script src="<?php echo e(asset('back/js/flatpicker.js')); ?>"></script>
<script>
	flatpickr('#published_at', {
		enableTime: true
	})
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/posts/create.blade.php ENDPATH**/ ?>