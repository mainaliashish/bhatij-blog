					<!-- AddToAny BEGIN -->
					<div class="a2a_kit a2a_kit_size_32 a2a_default_style" style="margin-top: 18px;">
					<a class="a2a_button_facebook"></a>
					<a class="a2a_button_twitter"></a>
					<a class="a2a_button_email"></a>
					<a class="a2a_button_pinterest"></a>
					<a class="a2a_button_whatsapp"></a>
					<a class="a2a_button_reddit"></a>
					</div>
					<script async src="https://static.addtoany.com/menu/page.js"></script>
					<!-- AddToAny END -->
				</div>
			 </div><?php /**PATH /home/ashish/Sites/vatiz/resources/views/partials/share.blade.php ENDPATH**/ ?>