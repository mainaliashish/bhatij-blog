<?php $__env->startSection('header'); ?>
<style>
header.panel-heading.custom {
    background: antiquewhite;
    color: sienna;
    font-size: x-large;
    font-family: sans-serif;
    font-weight: 600;
    box-shadow: 3px 3px darkolivegreen;
}

.alert.alert-danger {
    color: firebrick;
    font-size: 16px;
    font-family: sans-serif;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="container">
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header end-->
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	 <div class="panel panel-default">
    <div class="panel-heading">
    <?php if(isset($category)): ?>
     Edit Category
    <?php else: ?>
     Create a New Category
    <?php endif; ?>
    </div>

 	<?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	<div class="custom" style="padding: 12px">
 		<?php if(isset($category)): ?>
		<?php echo Form::model($category, ['method'=>'PATCH', 'route' => ['categories.update', $category->id]]); ?>

		<?php else: ?>
		<?php echo e(Form::open(array('method'=>'POST','route' => 'categories.store'))); ?>

		<?php endif; ?>
		<div class="form-group">
			<?php echo Form::label('category', 'Category : ', ['class' => 'font-weight-bold']); ?>

			<?php echo Form::text('name', isset($category) ? $category->name : ' ' , ['class' => 'form-control','placeholder'=>'Enter title']); ?>

		</div>

		<div class="form-group right">
			<?php echo e(Form::submit(isset($category) ? 'Update category' : 'Create category',['class' => 'btn btn-success'])); ?>

		</div>
		<?php echo Form::close(); ?>

 	</div>
<?php echo $__env->make('vatiz-back.layouts.back-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/categories/create.blade.php ENDPATH**/ ?>