<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('back/css/trix.css')); ?>" />
<style type="text/css">
	trix-editor {
		height: 500px !important;
		max-height: 200px;
	  	overflow-y: auto !important;
	}

header.panel-heading.custom {
    background: antiquewhite;
    color: sienna;
    font-size: x-large;
    font-family: sans-serif;
    font-weight: 600;
    box-shadow: 3px 3px darkolivegreen;
}

.alert.alert-danger {
    color: firebrick;
    font-size: 16px;
    font-family: sans-serif;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="container">
<?php echo $__env->make('vatiz-back.layouts.back-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--header end-->
<!--sidebar start-->
<?php echo $__env->make('vatiz-back.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
	<section class="wrapper">
	 <div class="panel panel-default">
    <div class="panel-heading">
		Update Admin Password
    </div>

 	<?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	<div class="custom" style="padding: 12px">
        <form method="POST" action="<?php echo e(route('settings.updatepassword')); ?>">
         <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <?php echo Form::label('current-password', 'Current password:', ['class' => 'font-weight-bold']); ?>

		  <?php echo Form::password('current-password', ['class' => 'form-control','placeholder'=>'Enter current password']); ?>

        </div>

        <div class="form-group">
          <?php echo Form::label('new-password', 'New password:', ['class' => 'font-weight-bold']); ?>

		  <?php echo Form::password('new-password', ['class'=> 'form-control', 'placeholder' => 'Enter new password']); ?>


        </div>

        <div class="form-group">
          <?php echo Form::label('new-password_confirmation', 'Confirm password:', ['class' => 'font-weight-bold']); ?>

		  <?php echo Form::password('new-password_confirmation', ['class' => 'form-control','placeholder'=>'Enter confirm password']); ?>

        </div>

		<div class="form-group right">
			<?php echo e(Form::submit('Update Password',['class' => 'btn btn-success'])); ?>

		</div>
		<?php echo Form::close(); ?>

 	</div>
<?php echo $__env->make('vatiz-back.layouts.back-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="<?php echo e(asset('back/js/trix.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('vatiz-back.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/settings/changepassword.blade.php ENDPATH**/ ?>