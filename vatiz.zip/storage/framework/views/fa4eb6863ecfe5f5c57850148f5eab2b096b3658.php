<!DOCTYPE HTML>
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo e(asset('/front/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css' />

<link rel="icon" href="<?php echo e(asset('logo/site-logo.png')); ?>">
<!-- Custom Theme files -->
<link href='//fonts.googleapis.com/css?family=Raleway:400,600,700' rel='stylesheet' type='text/css'>
<link href="<?php echo e(asset('front/css/style.css')); ?>" rel='stylesheet' type='text/css' />
<script src="<?php echo e(asset('front/js/jquery-1.11.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<!-- animation-effect -->
<link href="<?php echo e(asset('front/css/animate.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
</head><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/layouts/header.blade.php ENDPATH**/ ?>