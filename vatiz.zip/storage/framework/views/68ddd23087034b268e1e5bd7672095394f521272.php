<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="index.html">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>


                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-bullhorn"></i>
                        <span>Categories</span>
                    </a>
                    <ul class="sub">
                        <li><a href="<?php echo e(route('categories.index')); ?>">Categories</a></li>
                        <li><a href="<?php echo e(route('categories.create')); ?>">Create Category</a></li>
                    </ul>
                </li>


                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Blog Posts</span>
                    </a>
                    <ul class="sub">
						<li><a href="<?php echo e(route('posts.index')); ?>">Posts</a></li>
                        <li><a href="<?php echo e(route('posts.create')); ?>">Create Post</a></li>
                        <li><a href="<?php echo e(route('posts.trashed')); ?>">Trashed Posts</a></li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo e(route('settings.index')); ?>">
                        <i class="fa fa-user"></i>
                        <span>Site Settings</span>
                    </a>
                </li>


            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-back/layouts/sidebar.blade.php ENDPATH**/ ?>