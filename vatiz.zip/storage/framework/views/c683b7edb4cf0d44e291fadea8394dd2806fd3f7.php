<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/ashish/Sites/vatiz/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>