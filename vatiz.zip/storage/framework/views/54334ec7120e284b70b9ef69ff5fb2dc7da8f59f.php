<?php $__env->startSection('title'); ?>
...::Bhatij About::..
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('vatiz-front.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- technology-left -->
	<div class="technology">
	<div class="container">
		<div class="col-md-9 technology-left">
		<div class="w3agile-1">
			<div class="welcome">
				<div class="welcome-top heading">
					<h2 class="w3">About <?php echo e($setting->site_name); ?></h2>
					<div class="welcome-bottom">
						<img src="images/t4.jpg" class="img-responsive" alt="">
						<p><?php echo $setting->about; ?></p>
					</div>
				</div>
			</div>
			<div class="team">
				<h3 class="team-heading">Owner</h3>
				<div class="team-grids">
					<div class="col-md-6 team-grid">
						<div class="team-grid1">
							<img src="<?php echo e(asset($setting->image)); ?>" alt=" " class="img-responsive">
							<div class="p-mask">
								<p>About Admin</p>
							</div>
						</div>
						<h5><?php echo e(auth()->user()->name); ?><span>Admin of Bhatij Blog</span></h5>
						<ul class="social">
							<li><a class="social-facebook" href="https://www.facebook.com/Bhatij007/">
								<i></i>
								<div class="tooltip"><span>Facebook</span></div>
								</a></li>
							<li><a class="social-twitter" href="#">
								<i></i>
								<div class="tooltip"><span>Twitter</span></div>
								</a></li>
							<li><a class="social-google" href="#">
								<i></i>
								<div class="tooltip"><span>Google+</span></div>
								</a></li>
						</ul>
					</div>

					<div class="clearfix"> </div>
				</div>
			</div>
			</div>
		</div>
		<?php echo $__env->make('vatiz-front.layouts.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- technology-right -->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/about.blade.php ENDPATH**/ ?>