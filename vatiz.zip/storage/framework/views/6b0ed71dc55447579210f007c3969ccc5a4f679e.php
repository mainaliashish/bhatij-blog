<?php $__env->startSection('title'); ?>
...::Bhatij Blog::..
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('vatiz-front.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- technology-left -->
	<div class="technology">
	<div class="container">
		<div class="col-md-9 technology-left">
		<div class="tech-no">

			<?php if($posts): ?>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="tc-ch wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">

					<div class="tch-img">
						<a href="<?php echo e(route('single', $post->slug)); ?>">
						<img src="<?php echo e(asset($post->image)); ?>" alt="" width="100%" height="330px;"> </a>
					</div>

					<h3><a href="<?php echo e(route('single', $post->slug)); ?>"><?php echo e($post->title); ?></a></h3>
					<h6> BY <a href="<?php echo e(route('about')); ?>"><?php echo e($post->author); ?> </a>
					<?php echo e($post -> created_at->toFormattedDateString()); ?>

					</h6>
						<p><?php echo e(str_limit($post->description, 350, '......')); ?></p>
						<div class="bht1">
							<a href="<?php echo e(route('single', $post->slug)); ?>">Continue Reading</a>
						</div>
						<div class="soci">
							<ul>
								<li class="hvr-rectangle-out"><a class="fb" href="#"></a></li>
								<li class="hvr-rectangle-out"><a class="twit" href="#"></a></li>
								<li class="hvr-rectangle-out"><a class="goog" href="#"></a></li>
								<li class="hvr-rectangle-out"><a class="pin" href="#"></a></li>
								<li class="hvr-rectangle-out"><a class="drib" href="#"></a></li>
							</ul>
						</div>
						<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			</div>
			<?php echo e($posts->links()); ?>

		</div>

		<?php echo $__env->make('vatiz-front.layouts.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/home.blade.php ENDPATH**/ ?>