<?php $__env->startSection('content'); ?>
<body>
<?php echo $__env->make('vatiz-front.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- technology-left -->
	<div class="technology">
	<div class="container">
		<div class="col-md-9 technology-left">
			<div class="agileinfo">
			<h3 style="font-family: sans-serif;font-style: italic;">Search result for : <strong style="color: tomato"><?php echo e($query); ?></strong></h3>
			<?php if($posts ->count() > 0): ?>
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="single">
			  <a href="<?php echo e(route('single', $post->slug)); ?>"> <img src="<?php echo e(asset($post->image)); ?>" class="img-responsive" alt=""> </a>
			    <div class="b-bottom">
			       <a href="<?php echo e(route('single', $post->slug)); ?>"><h5 class="top"><?php echo e($post->title); ?></h5></a>
				   <p class="sub"><?php echo e($post->desciption); ?></p>
			       <p>Published at : <?php echo e($post -> created_at->toFormattedDateString()); ?> </p>
				</div>
			 </div>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 <?php else: ?>
			 <div style="margin-top: 20px;">
			 <h3>No matching Post(s) found.</h3>
			 </div>
			 <?php endif; ?>

				<div class="clearfix"></div>
			</div>
		</div>
	<?php echo $__env->make('vatiz-front.layouts.right-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- technology-right -->
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vatiz-front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ashish/Sites/vatiz/resources/views/vatiz-front/results.blade.php ENDPATH**/ ?>